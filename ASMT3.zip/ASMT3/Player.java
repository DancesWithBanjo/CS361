
/**
 * A player to go into the priority queue
 * 
 * Christian Wiemer
 */
public class Player
{
    public String name;
    public int score;
    /**
     * Makes a player consisting of a name and score
     */
    public Player(String name, int score) {
      this.name = name;
      this.score = score;
    }
}

